import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Tv, 
  Layers, 
  Paintbrush, 
  Hammer, 
  Wrench, 
  Settings,
  Car,
  Check,
  Clock,
  DollarSign,
  ThumbsUp,
  Phone,
  Calendar,
  MapPin,
  Mail,
  Menu,
  X,
  Star
} from "lucide-react";
import logoImage from "@assets/BBA73064-0996-421A-808E-6900B12A163D_1755613209721.jpeg";

export default function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const services = [
    {
      icon: <Tv className="w-8 h-8 text-white" />,
      title: "TV Mounting",
      description: "Professional TV mounting and entertainment system setup. We ensure secure installation and clean cable management for the perfect viewing experience."
    },
    {
      icon: <Layers className="w-8 h-8 text-white" />,
      title: "Flooring",
      description: "Expert flooring installation and repairs including hardwood, laminate, vinyl, and tile. Transform your space with quality craftsmanship."
    },
    {
      icon: <Paintbrush className="w-8 h-8 text-white" />,
      title: "Painting",
      description: "Interior and exterior painting services to refresh and protect your property. Quality paints and professional techniques guaranteed."
    },
    {
      icon: <Car className="w-8 h-8 text-white" />,
      title: "Transportation Services",
      description: "Reliable transportation solutions including office drop-offs, airport shuttles, medical courier services, and other professional transport needs."
    },
    {
      icon: <Settings className="w-8 h-8 text-white" />,
      title: "Installations",
      description: "From appliances to fixtures, we handle all your installation needs including ceiling fans, light fixtures, and smart home devices."
    },
    {
      icon: <Wrench className="w-8 h-8 text-white" />,
      title: "General Repairs",
      description: "Quick fixes and maintenance tasks including drywall repairs, caulking, weatherproofing, and general home maintenance."
    }
  ];

  const testimonials = [
    {
      name: "John Smith",
      location: "Worcester, MA",
      rating: 5,
      review: "Professional service from start to finish. They mounted our 65\" TV perfectly and cleaned up everything afterward. Highly recommend!",
      initials: "JS"
    },
    {
      name: "Maria Johnson",
      location: "Worcester, MA",
      rating: 5,
      review: "Amazing work on our bathroom flooring. Arrived on time, worked efficiently, and the result exceeded our expectations.",
      initials: "MJ"
    },
    {
      name: "Robert Brown",
      location: "Worcester, MA",
      rating: 5,
      review: "Fair pricing and excellent craftsmanship. They painted our entire office space and it looks fantastic. Will definitely use again.",
      initials: "RB"
    }
  ];

  const guarantees = [
    {
      icon: <Check className="w-5 h-5 text-white" />,
      title: "Licensed & Insured",
      description: "Fully licensed and insured for your peace of mind."
    },
    {
      icon: <Check className="w-5 h-5 text-white" />,
      title: "Satisfaction Guaranteed",
      description: "We stand behind our work with a 100% satisfaction guarantee."
    },
    {
      icon: <Check className="w-5 h-5 text-white" />,
      title: "Local Worcester Business",
      description: "Proud to serve our local community with reliable service."
    }
  ];

  const ctaFeatures = [
    {
      icon: <Clock className="w-8 h-8 text-lime-accent" />,
      title: "Same Day Service",
      description: "Available for urgent repairs and installations"
    },
    {
      icon: <DollarSign className="w-8 h-8 text-lime-accent" />,
      title: "Free Estimates",
      description: "No obligation quotes for all projects"
    },
    {
      icon: <ThumbsUp className="w-8 h-8 text-lime-accent" />,
      title: "Quality Guarantee",
      description: "100% satisfaction on every job"
    }
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-charcoal text-white">
        {/* Navigation */}
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={logoImage} 
                alt="MX Starlight Logo" 
                className="w-12 h-12 rounded-lg object-cover"
                data-testid="logo-image"
              />
              <div>
                <h1 className="text-xl font-bold" data-testid="company-name">MX Starlight</h1>
                <p className="text-lime-accent text-sm" data-testid="company-tagline">Handyman Services</p>
              </div>
            </div>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-white hover:text-lime-accent hover:bg-charcoal"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
            
            {/* Desktop navigation */}
            <div className="hidden md:flex items-center space-x-6">
              <button 
                onClick={() => scrollToSection('services')} 
                className="hover:text-lime-accent transition-colors"
                data-testid="link-services"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection('about')} 
                className="hover:text-lime-accent transition-colors"
                data-testid="link-about"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="hover:text-lime-accent transition-colors"
                data-testid="link-contact"
              >
                Contact
              </button>
              <Button 
                asChild
                className="bg-sea-green hover:bg-forest-green px-4 py-2 rounded-lg transition-colors font-medium"
                data-testid="button-book-now-nav"
              >
                <a href="https://calendly.com/mxstarlight1" target="_blank" rel="noopener noreferrer">
                  Book Now
                </a>
              </Button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-gray-700 pt-4">
              <div className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('services')} 
                  className="text-left hover:text-lime-accent transition-colors"
                  data-testid="link-services-mobile"
                >
                  Services
                </button>
                <button 
                  onClick={() => scrollToSection('about')} 
                  className="text-left hover:text-lime-accent transition-colors"
                  data-testid="link-about-mobile"
                >
                  About
                </button>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="text-left hover:text-lime-accent transition-colors"
                  data-testid="link-contact-mobile"
                >
                  Contact
                </button>
                <Button 
                  asChild
                  className="bg-sea-green hover:bg-forest-green w-full"
                  data-testid="button-book-now-mobile"
                >
                  <a href="https://calendly.com/mxstarlight1" target="_blank" rel="noopener noreferrer">
                    Book Now
                  </a>
                </Button>
              </div>
            </div>
          )}
        </nav>

        {/* Hero Section */}
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold mb-6" data-testid="hero-title">
              Bringing the Best to Your Home <span className="text-lime-accent">& Business</span>
            </h2>
            <p className="text-xl md:text-2xl mb-8 text-gray-300" data-testid="hero-subtitle">
              Professional handyman services in Worcester, MA. Quality work, reliable service, fair prices.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                asChild
                size="lg"
                className="bg-sea-green hover:bg-forest-green text-white px-8 py-4 text-lg font-semibold transition-all transform hover:scale-105 shadow-lg"
                data-testid="button-schedule-service"
              >
                <a href="https://calendly.com/mxstarlight1" target="_blank" rel="noopener noreferrer">
                  <Calendar className="w-5 h-5 mr-2" />
                  Schedule Service
                </a>
              </Button>
              <Button 
                asChild
                variant="outline"
                size="lg"
                className="border-2 border-lime-accent text-lime-accent hover:bg-lime-accent hover:text-charcoal px-8 py-4 text-lg font-semibold transition-all"
                data-testid="button-call-now"
              >
                <a href="tel:+12814750292">
                  <Phone className="w-5 h-5 mr-2" />
                  Call Now
                </a>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-charcoal mb-4" data-testid="services-title">Our Professional Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto" data-testid="services-subtitle">
              From small repairs to major installations, we handle it all with expertise and care.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card 
                key={index} 
                className="bg-gray-50 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 group border-0"
                data-testid={`card-service-${index}`}
              >
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-sea-green rounded-full flex items-center justify-center mb-6 group-hover:bg-forest-green transition-colors">
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-semibold text-charcoal mb-4" data-testid={`text-service-title-${index}`}>
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed" data-testid={`text-service-description-${index}`}>
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-charcoal mb-4" data-testid="testimonials-title">What Our Customers Say</h2>
            <p className="text-xl text-gray-600" data-testid="testimonials-subtitle">Trusted by homeowners and businesses across Worcester</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white shadow-lg border-0" data-testid={`card-testimonial-${index}`}>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="flex text-yellow-400" data-testid={`rating-${index}`}>
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-current" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700 italic mb-4" data-testid={`text-review-${index}`}>
                    "{testimonial.review}"
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-sea-green rounded-full flex items-center justify-center text-white font-bold mr-4">
                      {testimonial.initials}
                    </div>
                    <div>
                      <p className="font-semibold" data-testid={`text-customer-name-${index}`}>{testimonial.name}</p>
                      <p className="text-gray-500 text-sm" data-testid={`text-customer-location-${index}`}>{testimonial.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-charcoal mb-6" data-testid="about-title">Why Choose MX Starlight?</h2>
              <p className="text-lg text-gray-600 mb-8" data-testid="about-description">
                With years of experience serving the Worcester community, we pride ourselves on delivering quality workmanship and exceptional customer service. Every project is completed with attention to detail and professional care.
              </p>
              
              <div className="space-y-6">
                {guarantees.map((guarantee, index) => (
                  <div key={index} className="flex items-start" data-testid={`guarantee-${index}`}>
                    <div className="w-8 h-8 bg-sea-green rounded-full flex items-center justify-center mr-4 mt-1">
                      {guarantee.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold text-charcoal mb-1" data-testid={`text-guarantee-title-${index}`}>
                        {guarantee.title}
                      </h3>
                      <p className="text-gray-600" data-testid={`text-guarantee-description-${index}`}>
                        {guarantee.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1504148455328-c376907d081c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Professional handyman at work" 
                className="rounded-lg shadow-lg w-full h-48 object-cover"
                data-testid="img-handyman-work"
              />
              <img 
                src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Professional tools and equipment" 
                className="rounded-lg shadow-lg w-full h-48 object-cover mt-8"
                data-testid="img-tools-equipment"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-forest-green text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4" data-testid="cta-title">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-gray-200 max-w-2xl mx-auto" data-testid="cta-description">
            Schedule your handyman service today. Quick booking, professional results, and satisfaction guaranteed.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              asChild
              size="lg"
              className="bg-lime-accent text-charcoal hover:bg-yellow-300 px-8 py-4 text-lg font-semibold transition-all transform hover:scale-105 shadow-lg"
              data-testid="button-book-appointment"
            >
              <a href="https://calendly.com/mxstarlight1" target="_blank" rel="noopener noreferrer">
                <Calendar className="w-5 h-5 mr-2" />
                Book Your Appointment
              </a>
            </Button>
            <Button 
              asChild
              variant="outline"
              size="lg"
              className="border-2 border-lime-accent text-lime-accent hover:bg-lime-accent hover:text-charcoal px-8 py-4 text-lg font-semibold transition-all"
              data-testid="button-call-phone"
            >
              <a href="tel:+12814750292">
                <Phone className="w-5 h-5 mr-2" />
                (281) 475-0292
              </a>
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {ctaFeatures.map((feature, index) => (
              <div key={index} data-testid={`cta-feature-${index}`}>
                <div className="flex justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="font-semibold mb-2" data-testid={`text-cta-feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-gray-200" data-testid={`text-cta-feature-description-${index}`}>
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-charcoal text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src={logoImage} 
                  alt="MX Starlight Logo" 
                  className="w-10 h-10 rounded-lg object-cover"
                  data-testid="logo-footer"
                />
                <div>
                  <h3 className="text-xl font-bold" data-testid="company-name-footer">MX Starlight</h3>
                  <p className="text-lime-accent" data-testid="company-tagline-footer">Handyman Services</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4" data-testid="company-description-footer">
                Professional handyman services for homes and businesses in Worcester, MA. Quality work, fair prices, guaranteed satisfaction.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4" data-testid="services-footer-title">Services</h4>
              <ul className="space-y-2 text-gray-300">
                <li><button onClick={() => scrollToSection('services')} className="hover:text-lime-accent transition-colors" data-testid="link-tv-mounting">TV Mounting</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-lime-accent transition-colors" data-testid="link-flooring">Flooring</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-lime-accent transition-colors" data-testid="link-painting">Painting</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-lime-accent transition-colors" data-testid="link-transportation">Transportation</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-lime-accent transition-colors" data-testid="link-installations">Installations</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4" data-testid="contact-info-title">Contact Info</h4>
              <div className="space-y-3 text-gray-300">
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 mr-3 text-lime-accent" />
                  <span data-testid="text-location">Worcester, MA</span>
                </div>
                <div className="flex items-center">
                  <Phone className="w-5 h-5 mr-3 text-lime-accent" />
                  <a href="tel:+12814750292" className="hover:text-lime-accent transition-colors" data-testid="link-phone">
                    (281) 475-0292
                  </a>
                </div>
                <div className="flex items-center">
                  <Mail className="w-5 h-5 mr-3 text-lime-accent" />
                  <a href="mailto:mxstarlight1@gmail.com" className="hover:text-lime-accent transition-colors" data-testid="link-email">
                    mxstarlight1@gmail.com
                  </a>
                </div>
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 mr-3 text-lime-accent" />
                  <a href="https://calendly.com/mxstarlight1" target="_blank" rel="noopener noreferrer" className="hover:text-lime-accent transition-colors" data-testid="link-book-online">
                    Book Online
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p data-testid="copyright">&copy; 2025 MX Starlight Handyman Services. All rights reserved. | Worcester, MA</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
